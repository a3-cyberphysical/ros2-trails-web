from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():
    share = Path(get_package_share_directory('frame_detective'))
    robot_description = (share / 'urdf' / 'detective.urdf').read_text()
    fault_mode = LaunchConfiguration('fault_mode')
    return LaunchDescription([
        DeclareLaunchArgument(
            'fault_mode', default_value='correct',
            description='correct, reversed, disconnected, stale, or future'),
        Node(
            package='robot_state_publisher', executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description}],
            condition=IfCondition(PythonExpression(["'", fault_mode, "' == 'correct'"]))),
        Node(
            package='frame_detective', executable='frame_source',
            parameters=[{'fault_mode': fault_mode}], output='screen'),
        Node(
            package='frame_detective', executable='detection_transformer',
            output='screen'),
        Node(
            package='rviz2', executable='rviz2', output='screen',
            arguments=['-d', str(share / 'rviz' / 'detective.rviz')]),
    ])
