from glob import glob
from setuptools import find_packages, setup

package_name = 'frame_detective'
setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        ('share/' + package_name + '/urdf', glob('urdf/*')),
        ('share/' + package_name + '/rviz', glob('rviz/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ROS 2 Trails maintainers',
    maintainer_email='maintainers@example.com',
    description='Timed tf2 and RViz fault lab.',
    license='MIT',
    entry_points={'console_scripts': [
        'frame_source = frame_detective.frame_source:main',
        'detection_transformer = frame_detective.detection_transformer:main',
    ]},
)
