import math

import rclpy
from geometry_msgs.msg import PointStamped, TransformStamped
from rclpy.duration import Duration
from rclpy.node import Node
from tf2_ros import StaticTransformBroadcaster, TransformBroadcaster


class FrameSource(Node):
    def __init__(self):
        super().__init__('frame_source')
        self.declare_parameter('fault_mode', 'correct')
        self.declare_parameter('angular_speed', 0.25)
        self.dynamic = TransformBroadcaster(self)
        self.static = StaticTransformBroadcaster(self)
        self.detections = self.create_publisher(PointStamped, '/sensor/detection', 10)
        self.started = self.get_clock().now()
        if self.get_parameter('fault_mode').value != 'correct':
            self.publish_sensor_mount()
        self.create_timer(0.05, self.tick)

    def publish_sensor_mount(self):
        mode = self.get_parameter('fault_mode').value
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        if mode == 'reversed':
            transform.header.frame_id = 'sensor_link'
            transform.child_frame_id = 'base_link'
            transform.transform.translation.x = -0.20
            transform.transform.translation.z = -0.10
        else:
            transform.header.frame_id = 'orphan' if mode == 'disconnected' else 'base_link'
            transform.child_frame_id = 'sensor_link'
            transform.transform.translation.x = 0.20
            transform.transform.translation.z = 0.10
        transform.transform.rotation.w = 1.0
        self.static.sendTransform(transform)

    def tick(self):
        now = self.get_clock().now()
        elapsed = (now - self.started).nanoseconds / 1e9
        angle = self.get_parameter('angular_speed').value * elapsed
        transform = TransformStamped()
        transform.header.stamp = now.to_msg()
        transform.header.frame_id = 'map'
        transform.child_frame_id = 'base_link'
        transform.transform.translation.x = 1.5 * math.cos(angle)
        transform.transform.translation.y = 1.5 * math.sin(angle)
        transform.transform.rotation.z = math.sin((angle + math.pi / 2.0) / 2.0)
        transform.transform.rotation.w = math.cos((angle + math.pi / 2.0) / 2.0)
        self.dynamic.sendTransform(transform)

        detection = PointStamped()
        mode = self.get_parameter('fault_mode').value
        stamp = now
        if mode == 'stale':
            stamp = now - Duration(seconds=5.0)
        elif mode == 'future':
            stamp = now + Duration(seconds=2.0)
        detection.header.stamp = stamp.to_msg()
        detection.header.frame_id = 'sensor_link'
        detection.point.x = 1.0
        self.detections.publish(detection)


def main():
    rclpy.init()
    node = FrameSource()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
