import rclpy
from geometry_msgs.msg import PointStamped
from rclpy.node import Node
from std_msgs.msg import String
from tf2_geometry_msgs import do_transform_point  # registers PointStamped support
from tf2_ros import Buffer, TransformException, TransformListener
from visualization_msgs.msg import Marker


class DetectionTransformer(Node):
    def __init__(self):
        super().__init__('detection_transformer')
        self.buffer = Buffer()
        self.listener = TransformListener(self.buffer, self)
        self.marker = self.create_publisher(Marker, '/detection_marker', 10)
        self.status = self.create_publisher(String, '/frame_detective/status', 10)
        self.create_subscription(PointStamped, '/sensor/detection', self.on_detection, 10)

    def on_detection(self, message):
        try:
            transformed = self.buffer.transform(message, 'map')
        except TransformException as error:
            self.status.publish(String(data=f'error: {type(error).__name__}: {error}'))
            return
        marker = Marker()
        marker.header = transformed.header
        marker.ns = 'detections'
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.pose.position = transformed.point
        marker.pose.orientation.w = 1.0
        marker.scale.x = marker.scale.y = marker.scale.z = 0.16
        marker.color.r = 0.15
        marker.color.g = 0.90
        marker.color.b = 0.35
        marker.color.a = 1.0
        self.marker.publish(marker)
        self.status.publish(String(data='ok'))


def main():
    rclpy.init()
    node = DetectionTransformer()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
