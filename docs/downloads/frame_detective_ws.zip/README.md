# Frame Detective workspace

ROS 2 Jazzy preview workspace for the ROS 2 Trails Frame Detective project.

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src --rosdistro jazzy -y
colcon build --symlink-install
source install/local_setup.bash
ros2 launch frame_detective display.launch.py
```

Choose `fault_mode:=correct|reversed|disconnected|stale|future`. See the onsite
course before interpreting a fault. Code is MIT licensed.
