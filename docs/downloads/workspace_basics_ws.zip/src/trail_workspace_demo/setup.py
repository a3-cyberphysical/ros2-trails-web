from setuptools import find_packages, setup

package_name = "trail_workspace_demo"

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(),
    data_files=[
        ("share/ament_index/resource_index/packages", [f"resource/{package_name}"]),
        (f"share/{package_name}", ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="ROS 2 Trails maintainers",
    maintainer_email="maintainers@example.invalid",
    description="Local package for the ROS 2 Trails workspace lesson.",
    license="Apache-2.0",
    entry_points={"console_scripts": ["beacon = trail_workspace_demo.beacon:main"]},
)
