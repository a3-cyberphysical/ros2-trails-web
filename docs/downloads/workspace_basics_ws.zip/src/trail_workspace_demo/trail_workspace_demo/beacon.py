import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class Beacon(Node):
    def __init__(self) -> None:
        super().__init__("workspace_beacon")
        self.publisher = self.create_publisher(String, "/workspace_beacon", 10)
        self.timer = self.create_timer(1.0, self.publish_beacon)

    def publish_beacon(self) -> None:
        message = String()
        message.data = "local workspace discovered"
        self.publisher.publish(message)


def main() -> None:
    rclpy.init()
    node = Beacon()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
