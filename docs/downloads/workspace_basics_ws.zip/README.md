# Workspace basics starter

This original ROS 2 Trails example contains one minimal `ament_python` package
for the workspace lesson. It has no fetched source or runtime network dependency.

Copy `src/trail_workspace_demo` into the course workspace, build it, and verify
its installed prefix as directed by the onsite lesson.
