# Notebook Robotics Lab

Three local notebooks teach bounded live ROS sampling, trajectory analysis, and
offline controller tuning. Start Jupyter from a shell that has sourced ROS 2
Jazzy. Stable robot/simulator processes and emergency stops stay outside the kernel.

```bash
source /opt/ros/jazzy/setup.bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
./run_lab.sh
```

Restart Kernel and Run All before reporting evidence. The live notebook is a
preview until verified in the exact Jazzy environment; the two offline notebooks
use deterministic bundled data and functions.
