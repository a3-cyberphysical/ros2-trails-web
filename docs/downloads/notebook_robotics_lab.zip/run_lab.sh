#!/usr/bin/env bash
set -euo pipefail

if [[ "${ROS_DISTRO:-}" != "jazzy" ]]; then
  echo "Source /opt/ros/jazzy/setup.bash before starting the lab." >&2
  exit 1
fi
python -c 'import rclpy; print("ROS Python ready")'
exec python -m jupyterlab --notebook-dir="$(cd "$(dirname "$0")" && pwd)"
