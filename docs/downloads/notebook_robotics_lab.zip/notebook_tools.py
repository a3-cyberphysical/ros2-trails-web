"""Small, explicit helpers for the Notebook Robotics Lab."""

from __future__ import annotations

import csv
import math
import time
from pathlib import Path
from typing import Any, Callable, Iterable


def trajectory_metrics(rows: Iterable[dict[str, float]], command_limit: float = 1.2) -> dict[str, float]:
    samples = list(rows)
    if len(samples) < 2:
        raise ValueError("at least two samples are required")
    times = [float(row["time_s"]) for row in samples]
    if any(later <= earlier for earlier, later in zip(times, times[1:])):
        raise ValueError("timestamps must be strictly increasing")
    gaps = [later - earlier for earlier, later in zip(times, times[1:])]
    errors = [float(row["error_m"]) for row in samples]
    commands = [float(row["command_rad_s"]) for row in samples]
    return {
        "samples": float(len(samples)),
        "rms_error_m": math.sqrt(sum(value * value for value in errors) / len(errors)),
        "peak_error_m": max(abs(value) for value in errors),
        "max_gap_s": max(gaps),
        "saturation_fraction": sum(abs(value) >= command_limit for value in commands) / len(commands),
    }


def load_trial(path: str | Path) -> list[dict[str, float]]:
    with Path(path).open(newline="") as stream:
        return [{key: float(value) for key, value in row.items()} for row in csv.DictReader(stream)]


def simulate_line_controller(kp: float, kd: float, initial_error: float = 0.25,
                             dt: float = 0.05, steps: int = 160,
                             command_limit: float = 1.2) -> dict[str, Any]:
    if kp < 0 or kd < 0 or dt <= 0 or steps < 2:
        raise ValueError("gains must be nonnegative and time/steps positive")
    error = initial_error
    previous = error
    rows: list[dict[str, float]] = []
    for index in range(steps):
        derivative = (error - previous) / dt
        raw = kp * error + kd * derivative
        command = max(-command_limit, min(command_limit, raw))
        previous = error
        error += dt * (-0.72 * command + 0.10 * math.sin(index * dt * 1.7))
        rows.append({"time_s": index * dt, "error_m": error, "command_rad_s": command})
    metrics = trajectory_metrics(rows, command_limit)
    metrics["kp"] = kp
    metrics["kd"] = kd
    metrics["passes"] = metrics["rms_error_m"] < 0.12 and metrics["peak_error_m"] < 0.30 and metrics["saturation_fraction"] < 0.15
    return {"rows": rows, "metrics": metrics}


class RosSession:
    """One explicit rclpy context/node/executor lifecycle for a notebook."""

    def __init__(self, node_name: str = "notebook_probe") -> None:
        import rclpy
        from rclpy.context import Context
        from rclpy.executors import SingleThreadedExecutor

        self._rclpy = rclpy
        self.context = Context()
        rclpy.init(context=self.context)
        self.node = rclpy.create_node(node_name, context=self.context)
        self.executor = SingleThreadedExecutor(context=self.context)
        self.executor.add_node(self.node)
        self._closed = False

    def sample_for(self, message_type: type, topic: str, duration_s: float,
                   transform: Callable[[Any, float], Any]) -> list[Any]:
        if self._closed or duration_s <= 0:
            raise ValueError("session must be open and duration positive")
        samples: list[Any] = []
        started = time.monotonic()
        subscription = self.node.create_subscription(
            message_type, topic,
            lambda message: samples.append(transform(message, time.monotonic() - started)), 10)
        try:
            while time.monotonic() - started < duration_s:
                self.executor.spin_once(timeout_sec=min(0.05, duration_s))
        finally:
            self.node.destroy_subscription(subscription)
        return samples

    def close(self) -> None:
        if self._closed:
            return
        self.executor.remove_node(self.node)
        self.node.destroy_node()
        self.executor.shutdown(timeout_sec=1.0)
        self.context.shutdown()
        self._closed = True

    def __enter__(self) -> "RosSession":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
