from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('coverage', default_value='good'),
        DeclareLaunchArgument('calibration_output', default_value='/tmp/camera_detective.yaml'),
        Node(
            package='camera_detective', executable='synthetic_camera',
            namespace='camera', output='screen', parameters=[{
                'coverage': LaunchConfiguration('coverage'),
                'calibration_output': LaunchConfiguration('calibration_output'),
            }]),
    ])
