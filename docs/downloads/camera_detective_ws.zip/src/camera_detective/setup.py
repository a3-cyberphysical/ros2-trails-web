from glob import glob
from setuptools import find_packages, setup

package_name = 'camera_detective'
setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ROS 2 Trails maintainers',
    maintainer_email='maintainers@example.com',
    description='Synthetic camera calibration lab.',
    license='MIT',
    entry_points={'console_scripts': [
        'synthetic_camera = camera_detective.synthetic_camera:main',
        'evaluate_calibration = camera_detective.evaluate_calibration:main',
    ]},
)
