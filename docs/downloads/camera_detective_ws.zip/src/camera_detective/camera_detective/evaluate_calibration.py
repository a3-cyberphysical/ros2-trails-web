import argparse
from pathlib import Path

import yaml

from .scoring import calibration_is_acceptable


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--calibration', required=True)
    parser.add_argument('--held-out-residual', required=True, type=float)
    parser.add_argument('--threshold', default=1.0, type=float)
    args = parser.parse_args()
    calibration = yaml.safe_load(Path(args.calibration).read_text())
    passed = calibration_is_acceptable(
        calibration, args.held_out_residual, args.threshold)
    print(f'calibration_accepted={str(passed).lower()} '
          f'held_out_residual_px={args.held_out_residual:.3f} '
          f'threshold_px={args.threshold:.3f}')
    raise SystemExit(0 if passed else 1)
