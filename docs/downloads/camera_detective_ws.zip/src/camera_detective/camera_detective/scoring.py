def calibration_is_acceptable(calibration, held_out_residual, threshold=1.0):
    matrix = calibration.get('camera_matrix', {}).get('data', [])
    distortion = calibration.get('distortion_coefficients', {}).get('data', [])
    dimensions_ok = calibration.get('image_width') == 640 and calibration.get('image_height') == 480
    matrix_ok = len(matrix) == 9 and matrix[0] > 0.0 and matrix[4] > 0.0 and matrix[8] == 1.0
    distortion_ok = len(distortion) >= 4 and all(abs(value) < 2.0 for value in distortion)
    return dimensions_ok and matrix_ok and distortion_ok and 0.0 <= held_out_residual < threshold
