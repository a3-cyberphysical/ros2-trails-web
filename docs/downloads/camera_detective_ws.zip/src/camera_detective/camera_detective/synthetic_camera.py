import math
from pathlib import Path

import cv2
import numpy as np
import rclpy
import yaml
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image
from sensor_msgs.srv import SetCameraInfo


WIDTH, HEIGHT = 640, 480


def info_to_dict(info):
    return {
        'image_width': info.width,
        'image_height': info.height,
        'camera_name': 'camera_detective',
        'camera_matrix': {'rows': 3, 'cols': 3, 'data': list(info.k)},
        'distortion_model': info.distortion_model,
        'distortion_coefficients': {'rows': 1, 'cols': len(info.d), 'data': list(info.d)},
        'rectification_matrix': {'rows': 3, 'cols': 3, 'data': list(info.r)},
        'projection_matrix': {'rows': 3, 'cols': 4, 'data': list(info.p)},
    }


def dict_to_info(data):
    info = CameraInfo()
    info.width = int(data['image_width'])
    info.height = int(data['image_height'])
    info.distortion_model = data.get('distortion_model', 'plumb_bob')
    info.d = data['distortion_coefficients']['data']
    info.k = data['camera_matrix']['data']
    info.r = data['rectification_matrix']['data']
    info.p = data['projection_matrix']['data']
    return info


class SyntheticCamera(Node):
    def __init__(self):
        super().__init__('synthetic_camera')
        self.declare_parameter('coverage', 'good')
        self.declare_parameter('calibration_output', '/tmp/camera_detective.yaml')
        self.bridge = CvBridge()
        self.images = self.create_publisher(Image, 'image_raw', qos_profile_sensor_data)
        self.infos = self.create_publisher(CameraInfo, 'camera_info', qos_profile_sensor_data)
        self.create_service(SetCameraInfo, 'set_camera_info', self.set_camera_info)
        self.info = CameraInfo(width=WIDTH, height=HEIGHT, distortion_model='plumb_bob')
        self.info.r = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
        self.load_existing()
        self.frame = 0
        self.create_timer(0.1, self.tick)

    @property
    def output_path(self):
        return Path(self.get_parameter('calibration_output').value)

    def load_existing(self):
        if self.output_path.is_file():
            try:
                self.info = dict_to_info(yaml.safe_load(self.output_path.read_text()))
                self.get_logger().info(f'loaded calibration {self.output_path}')
            except (KeyError, TypeError, ValueError) as error:
                self.get_logger().error(f'ignored invalid calibration: {error}')

    def set_camera_info(self, request, response):
        info = request.camera_info
        if info.width != WIDTH or info.height != HEIGHT or info.k[0] <= 0.0:
            response.success = False
            response.status_message = 'expected 640x480 calibration with positive focal length'
            return response
        self.info = info
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.output_path.write_text(yaml.safe_dump(info_to_dict(info), sort_keys=False))
        response.success = True
        response.status_message = f'wrote {self.output_path}'
        self.get_logger().info(response.status_message)
        return response

    @staticmethod
    def board_image():
        square = 44
        board = np.full((7 * square, 9 * square, 3), 255, dtype=np.uint8)
        for row in range(7):
            for column in range(9):
                if (row + column) % 2 == 0:
                    cv2.rectangle(
                        board, (column * square, row * square),
                        ((column + 1) * square, (row + 1) * square), (15, 15, 15), -1)
        return board

    def destination(self, phase, mode):
        if mode == 'weak':
            cx = 320 + 12 * math.sin(phase)
            cy = 240 + 10 * math.cos(phase)
            width, height, skew = 330, 255, 4 * math.sin(phase)
        elif mode == 'held_out':
            cx = 320 + 115 * math.sin(phase * 0.7)
            cy = 240 + 80 * math.cos(phase * 0.9)
            width = 300 + 75 * math.sin(phase * 0.5)
            height, skew = width * 0.76, 32 * math.cos(phase * 0.6)
        else:
            cx = 320 + 185 * math.sin(phase * 0.8)
            cy = 240 + 125 * math.cos(phase * 0.63)
            width = 270 + 125 * (0.5 + 0.5 * math.sin(phase * 0.47))
            height, skew = width * 0.76, 48 * math.sin(phase * 0.71)
        return np.float32([
            [cx - width / 2 + skew, cy - height / 2],
            [cx + width / 2, cy - height / 2 + skew / 2],
            [cx + width / 2 - skew, cy + height / 2],
            [cx - width / 2, cy + height / 2 - skew / 2],
        ])

    @staticmethod
    def distort(image):
        yy, xx = np.indices((HEIGHT, WIDTH), dtype=np.float32)
        nx = (xx - WIDTH / 2) / (WIDTH / 2)
        ny = (yy - HEIGHT / 2) / (HEIGHT / 2)
        radius = nx * nx + ny * ny
        factor = 1.0 + 0.16 * radius - 0.05 * radius * radius
        map_x = (nx * factor * WIDTH / 2 + WIDTH / 2).astype(np.float32)
        map_y = (ny * factor * HEIGHT / 2 + HEIGHT / 2).astype(np.float32)
        return cv2.remap(image, map_x, map_y, cv2.INTER_LINEAR, borderValue=(70, 75, 85))

    def tick(self):
        board = self.board_image()
        source = np.float32([[0, 0], [board.shape[1] - 1, 0],
                             [board.shape[1] - 1, board.shape[0] - 1],
                             [0, board.shape[0] - 1]])
        mode = self.get_parameter('coverage').value
        transform = cv2.getPerspectiveTransform(source, self.destination(self.frame * 0.08, mode))
        canvas = np.full((HEIGHT, WIDTH, 3), (70, 75, 85), dtype=np.uint8)
        warped = cv2.warpPerspective(board, transform, (WIDTH, HEIGHT), borderValue=(70, 75, 85))
        mask = cv2.warpPerspective(np.full(board.shape[:2], 255, dtype=np.uint8),
                                   transform, (WIDTH, HEIGHT))
        canvas[mask > 0] = warped[mask > 0]
        canvas = self.distort(canvas)
        stamp = self.get_clock().now().to_msg()
        image = self.bridge.cv2_to_imgmsg(canvas, encoding='bgr8')
        image.header.stamp = stamp
        image.header.frame_id = 'camera_optical_frame'
        info = self.info
        info.header.stamp = stamp
        info.header.frame_id = 'camera_optical_frame'
        self.images.publish(image)
        self.infos.publish(info)
        self.frame += 1


def main():
    rclpy.init()
    node = SyntheticCamera()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
