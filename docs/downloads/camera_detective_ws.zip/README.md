# Camera Detective workspace

Synthetic ROS 2 Jazzy camera-calibration preview for Practical ROS 2.

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src --rosdistro jazzy -y
colcon build --symlink-install
source install/local_setup.bash
ros2 launch camera_detective camera.launch.py coverage:=good
```

See the onsite course for collection, calibration, rectification, and evaluation.
Code is MIT licensed.
