# Balance Bot example workspace

This source tree accompanies the local Balance Bot project trail. It targets
Ubuntu 24.04, ROS 2 Jazzy, and Gazebo Harmonic. The course currently labels it
preview until compiled and exercised in that exact runtime.

```bash
mkdir -p ~/balance_bot_ws
cp -a src ~/balance_bot_ws/
cd ~/balance_bot_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src --rosdistro jazzy -y
colcon build --symlink-install
source install/local_setup.bash
ros2 launch balance_bot_control balance.launch.py
```

Arm a manual run after joint state appears (the trial analyzer does this itself):

```bash
ros2 service call /balance_controller/start_trial std_srvs/srv/Trigger '{}'
```
