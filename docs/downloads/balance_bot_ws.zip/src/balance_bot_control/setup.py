from setuptools import find_packages, setup

package_name = 'balance_bot_control'
setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/balance.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ROS 2 Trails maintainers',
    maintainer_email='maintainers@example.com',
    description='Feedback controller for a simulated cart-pole.',
    license='MIT',
    entry_points={'console_scripts': [
        'balance_controller = balance_bot_control.controller:main',
        'trial_analyzer = balance_bot_control.trial_analyzer:main',
    ]},
)
