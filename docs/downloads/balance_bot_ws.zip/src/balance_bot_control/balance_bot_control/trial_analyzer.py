import csv
import math
import json

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray, String
from std_srvs.srv import Trigger
from .scoring import score_trial


class TrialAnalyzer(Node):
    def __init__(self):
        super().__init__('balance_trial_analyzer')
        self.declare_parameter('duration', 20.0)
        self.declare_parameter('output', 'trial.csv')
        self.started = None
        self.peak_angle_all = self.peak_angle_scored = 0.0
        self.peak_cart = self.peak_force = 0.0
        self.last_outside = 0.0
        self.samples = 0
        self.force_samples = 0
        self.first_state = None
        self.last_state_stamp = self.last_force_stamp = None
        self.max_state_gap = self.max_force_gap = 0.0
        self.stale_events = self.cutoff_events = self.saturation_samples = 0
        self.start_requested = False
        self.create_subscription(JointState, '/joint_states', self.on_state, 20)
        self.create_subscription(Float64MultiArray, '/cart_effort_controller/commands', self.on_force, 20)
        self.create_subscription(String, '/balance_controller/status', self.on_status, 20)
        self.start_client = self.create_client(Trigger, '/balance_controller/start_trial')
        self.create_timer(0.1, self.check_done)

    def reset_scored_metrics(self):
        self.peak_angle_all = self.peak_angle_scored = 0.0
        self.peak_cart = self.peak_force = self.last_outside = 0.0
        self.samples = self.force_samples = 0
        self.first_state = None
        self.last_state_stamp = self.last_force_stamp = None
        self.max_state_gap = self.max_force_gap = 0.0
        self.stale_events = self.cutoff_events = self.saturation_samples = 0

    def elapsed(self):
        if self.started is None:
            return 0.0
        return (self.get_clock().now() - self.started).nanoseconds / 1e9

    def on_state(self, message):
        try:
            cart_index = message.name.index('slider_to_cart')
            pole_index = message.name.index('cart_to_pendulum')
            cart = message.position[cart_index]
            cart_dot = message.velocity[cart_index]
            angle = message.position[pole_index]
            angle_dot = message.velocity[pole_index]
        except (ValueError, IndexError):
            return
        angle = math.atan2(math.sin(angle), math.cos(angle))
        now = self.get_clock().now()
        if self.first_state is None:
            self.first_state = (cart, cart_dot, angle, angle_dot)
        if self.last_state_stamp is not None:
            self.max_state_gap = max(self.max_state_gap, (now - self.last_state_stamp).nanoseconds / 1e9)
        self.last_state_stamp = now
        self.peak_cart = max(self.peak_cart, abs(cart))
        self.peak_angle_all = max(self.peak_angle_all, abs(angle))
        if self.elapsed() > 3.0:
            self.peak_angle_scored = max(self.peak_angle_scored, abs(angle))
        if self.elapsed() > 3.0 and abs(angle) >= 0.35:
            self.last_outside = self.elapsed()
        self.samples += 1

    def on_force(self, message):
        if message.data:
            now = self.get_clock().now()
            if self.last_force_stamp is not None:
                self.max_force_gap = max(self.max_force_gap, (now - self.last_force_stamp).nanoseconds / 1e9)
            self.last_force_stamp = now
            self.peak_force = max(self.peak_force, abs(message.data[0]))
            self.force_samples += 1

    def on_status(self, message):
        status = json.loads(message.data)
        if status['state'] == 'armed':
            self.reset_scored_metrics()
            self.started = self.get_clock().now()
        elif status['state'] == 'stale':
            self.stale_events += 1
        elif status['state'] == 'tilt_cutoff':
            self.cutoff_events += 1
        if status.get('saturated'):
            self.saturation_samples += 1

    def check_done(self):
        duration = self.get_parameter('duration').value
        if (not self.start_requested and self.first_state is not None
                and self.force_samples > 0 and self.start_client.service_is_ready()):
            self.start_requested = True
            future = self.start_client.call_async(Trigger.Request())
            future.add_done_callback(self.on_start_response)
        if self.started is None or self.elapsed() < duration:
            return
        metrics = {
            'state_samples': self.samples, 'force_samples': self.force_samples,
            'peak_angle_scored': self.peak_angle_scored, 'peak_cart': self.peak_cart,
            'peak_force': self.peak_force, 'stale_events': self.stale_events,
            'cutoff_events': self.cutoff_events, 'max_state_gap': self.max_state_gap,
            'max_force_gap': self.max_force_gap}
        passed = score_trial(metrics)
        output = self.get_parameter('output').value
        with open(output, 'w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=[
                'duration_s', 'samples', 'peak_angle_all_rad',
                'peak_angle_scored_rad', 'peak_cart_m',
                'force_samples', 'peak_force_n', 'initial_x', 'initial_x_dot',
                'initial_theta', 'initial_theta_dot', 'max_state_gap_s',
                'max_force_gap_s', 'stale_events', 'cutoff_events',
                'saturation_samples', 'settling_time_s', 'passed'])
            writer.writeheader()
            writer.writerow({
                'duration_s': duration, 'samples': self.samples,
                'peak_angle_all_rad': self.peak_angle_all,
                'peak_angle_scored_rad': self.peak_angle_scored,
                'peak_cart_m': self.peak_cart,
                'force_samples': self.force_samples,
                'peak_force_n': self.peak_force,
                'initial_x': self.first_state[0], 'initial_x_dot': self.first_state[1],
                'initial_theta': self.first_state[2], 'initial_theta_dot': self.first_state[3],
                'max_state_gap_s': self.max_state_gap, 'max_force_gap_s': self.max_force_gap,
                'stale_events': self.stale_events, 'cutoff_events': self.cutoff_events,
                'saturation_samples': self.saturation_samples,
                'settling_time_s': max(3.0, self.last_outside), 'passed': passed})
        self.get_logger().info(f'wrote {output}; passed={passed}')
        rclpy.shutdown()

    def on_start_response(self, future):
        try:
            response = future.result()
        except Exception as error:
            self.get_logger().error(f'trial start call failed: {error}')
            self.start_requested = False
            return
        if not response.success:
            self.get_logger().warn(f'trial start rejected; retrying: {response.message}')
            self.start_requested = False


def main():
    rclpy.init()
    rclpy.spin(TrialAnalyzer())
