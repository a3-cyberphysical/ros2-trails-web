import math
import json

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray, String
from std_srvs.srv import Trigger


class BalanceController(Node):
    def __init__(self):
        super().__init__('balance_controller')
        defaults = {
            'enabled': True, 'k_theta': 120.0, 'k_theta_dot': 22.0,
            'k_x': -4.0, 'k_x_dot': -8.0, 'max_force': 80.0,
            'max_tilt': 0.7, 'state_timeout': 0.2,
            'disturbance_at': 2.0, 'disturbance_force': 12.0,
            'disturbance_duration': 0.15,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        self.command = self.create_publisher(
            Float64MultiArray, '/cart_effort_controller/commands', 10)
        self.status = self.create_publisher(String, '/balance_controller/status', 10)
        self.create_service(Trigger, '/balance_controller/start_trial', self.start_trial)
        self.last_state_time = None
        self.trial_start_time = None
        self.state = None
        self.state_samples = 0
        self.was_stale = False
        self.create_subscription(JointState, '/joint_states', self.on_state, 20)
        self.create_timer(0.01, self.control)

    @staticmethod
    def state_for(message, name):
        index = message.name.index(name)
        return message.position[index], message.velocity[index]

    def on_state(self, message):
        try:
            x, x_dot = self.state_for(message, 'slider_to_cart')
            theta, theta_dot = self.state_for(message, 'cart_to_pendulum')
        except (ValueError, IndexError):
            self.get_logger().error('required joint state is missing')
            return
        theta = math.atan2(math.sin(theta), math.cos(theta))
        self.state = (x, x_dot, theta, theta_dot)
        self.last_state_time = self.get_clock().now()
        self.state_samples += 1
        if not self.get_parameter('enabled').value and self.state_samples % 100 == 0:
            self.get_logger().info(
                f'state x={x:.3f} x_dot={x_dot:.3f} theta={theta:.3f} theta_dot={theta_dot:.3f}')

    def publish_force(self, force):
        self.command.publish(Float64MultiArray(data=[float(force)]))

    def publish_status(self, state, saturated=False):
        self.status.publish(String(data=json.dumps({
            'state': state, 'saturated': saturated,
            'stamp_ns': self.get_clock().now().nanoseconds})))

    def start_trial(self, request, response):
        if self.state is None:
            response.success = False
            response.message = 'waiting for valid joint state'
            return response
        self.trial_start_time = self.get_clock().now()
        self.publish_status('armed')
        response.success = True
        response.message = 'trial clock reset and disturbance scheduled'
        return response

    def control(self):
        if self.state is None or self.last_state_time is None:
            return
        age = (self.get_clock().now() - self.last_state_time).nanoseconds / 1e9
        timeout = self.get_parameter('state_timeout').value
        if age > timeout:
            if not self.was_stale:
                self.get_logger().warn('joint state is stale; commanding zero force')
            self.was_stale = True
            self.publish_status('stale')
            self.publish_force(0.0)
            return
        self.was_stale = False
        if not self.get_parameter('enabled').value:
            self.publish_status('disabled')
            self.publish_force(0.0)
            return
        x, x_dot, theta, theta_dot = self.state
        if abs(theta) > self.get_parameter('max_tilt').value:
            self.get_logger().warn('tilt safety cutoff')
            self.publish_status('tilt_cutoff')
            self.publish_force(0.0)
            return
        force = (
            self.get_parameter('k_theta').value * theta
            + self.get_parameter('k_theta_dot').value * theta_dot
            + self.get_parameter('k_x').value * x
            + self.get_parameter('k_x_dot').value * x_dot
        )
        if self.trial_start_time is None:
            self.publish_status('waiting_for_start')
            self.publish_force(0.0)
            return
        now = (self.get_clock().now() - self.trial_start_time).nanoseconds / 1e9
        start = self.get_parameter('disturbance_at').value
        duration = self.get_parameter('disturbance_duration').value
        if start <= now < start + duration:
            force += self.get_parameter('disturbance_force').value
        limit = self.get_parameter('max_force').value
        saturated = abs(force) > limit
        self.publish_status('running', saturated)
        self.publish_force(max(-limit, min(limit, force)))


def main():
    rclpy.init()
    node = BalanceController()
    try:
        rclpy.spin(node)
    finally:
        node.publish_force(0.0)
        node.destroy_node()
        rclpy.shutdown()
