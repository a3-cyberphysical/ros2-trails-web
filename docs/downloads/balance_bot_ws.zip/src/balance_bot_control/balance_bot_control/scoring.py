def score_trial(metrics):
    """Return pass/fail from observable, unit-testable trial metrics."""
    return (
        metrics['state_samples'] >= 100
        and metrics['force_samples'] >= 100
        and metrics['peak_angle_scored'] < 0.35
        and metrics['peak_cart'] < 4.0
        and metrics['peak_force'] <= 80.0
        and metrics['stale_events'] == 0
        and metrics['cutoff_events'] == 0
        and metrics['max_state_gap'] <= 0.2
        and metrics['max_force_gap'] <= 0.2
    )
