from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    names = ['k_theta', 'k_theta_dot', 'k_x', 'k_x_dot', 'max_force',
             'disturbance_at', 'disturbance_force', 'disturbance_duration']
    defaults = ['120.0', '22.0', '-4.0', '-8.0', '80.0', '2.0', '12.0', '0.15']
    declarations = [DeclareLaunchArgument(name, default_value=value) for name, value in zip(names, defaults)]
    simulation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([
            FindPackageShare('balance_bot_description'), 'launch', 'simulation.launch.py'])))
    controller = Node(
        package='balance_bot_control', executable='balance_controller', output='screen',
        parameters=[{name: LaunchConfiguration(name) for name in names}, {'use_sim_time': True}])
    return LaunchDescription([*declarations, simulation, controller])
