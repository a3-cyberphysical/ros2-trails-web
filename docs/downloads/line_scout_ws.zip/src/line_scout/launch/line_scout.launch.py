from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    share = Path(get_package_share_directory('line_scout'))
    return LaunchDescription([
        DeclareLaunchArgument('controller_enabled', default_value='true'),
        DeclareLaunchArgument('kp', default_value='7.0'),
        DeclareLaunchArgument('kd', default_value='0.8'),
        Node(package='line_scout', executable='track_simulator', output='screen'),
        Node(package='line_scout', executable='line_controller', output='screen', parameters=[{
            'enabled': ParameterValue(LaunchConfiguration('controller_enabled'), value_type=bool),
            'kp': ParameterValue(LaunchConfiguration('kp'), value_type=float),
            'kd': ParameterValue(LaunchConfiguration('kd'), value_type=float)}]),
        Node(package='rviz2', executable='rviz2', output='screen',
             arguments=['-d', str(share / 'rviz' / 'line_scout.rviz')]),
    ])
