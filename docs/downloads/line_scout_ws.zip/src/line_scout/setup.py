from glob import glob
from setuptools import find_packages, setup

package_name = 'line_scout'
setup(
    name=package_name, version='0.1.0', packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        ('share/' + package_name + '/rviz', glob('rviz/*')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='ROS 2 Trails maintainers', maintainer_email='maintainers@example.com',
    description='Deterministic line-following lab.', license='MIT',
    entry_points={'console_scripts': [
        'track_simulator = line_scout.track_simulator:main',
        'line_controller = line_scout.line_controller:main',
        'trial_analyzer = line_scout.trial_analyzer:main',
    ]},
)
