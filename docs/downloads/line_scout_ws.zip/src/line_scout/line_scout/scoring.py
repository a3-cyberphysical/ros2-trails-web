def trial_passes(metrics):
    return (
        metrics['completion_x'] >= 8.0
        and metrics['rms_error'] < 0.12
        and metrics['peak_error'] < 0.30
        and metrics['saturation_fraction'] < 0.15
        and metrics['recoveries'] >= 1
        and metrics['terminal_stops'] == 0
        and metrics['max_gap'] <= 0.20
        and metrics['samples'] >= 100
    )
