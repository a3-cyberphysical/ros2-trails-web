import csv
import json
import math

import rclpy
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from std_msgs.msg import String

from .model import cross_track_error
from .scoring import trial_passes


class TrialAnalyzer(Node):
    def __init__(self):
        super().__init__('line_trial_analyzer')
        self.declare_parameter('duration', 60.0)
        self.declare_parameter('output', 'line-trial.csv')
        self.started = None
        self.last_sample = None
        self.max_gap = self.sum_squared = self.peak_error = self.completion_x = 0.0
        self.samples = self.commands = self.saturated = 0
        self.recoveries = self.terminal_stops = 0
        self.previous_state = None
        self.done = False
        self.create_subscription(Odometry, '/odom', self.on_odom, 20)
        self.create_subscription(TwistStamped, '/cmd_vel', self.on_command, 20)
        self.create_subscription(String, '/line_scout/status', self.on_status, 20)
        self.create_timer(0.1, self.check_done)

    def elapsed(self):
        return 0.0 if self.started is None else (self.get_clock().now() - self.started).nanoseconds / 1e9

    def on_odom(self, message):
        now = self.get_clock().now()
        if self.started is None:
            self.started = now
        if self.last_sample is not None:
            self.max_gap = max(self.max_gap, (now - self.last_sample).nanoseconds / 1e9)
        self.last_sample = now
        x = message.pose.pose.position.x
        error = cross_track_error(x, message.pose.pose.position.y)
        self.completion_x = max(self.completion_x, x)
        self.sum_squared += error * error
        self.peak_error = max(self.peak_error, abs(error))
        self.samples += 1

    def on_command(self, message):
        self.commands += 1

    def on_status(self, message):
        status = json.loads(message.data)
        state = status['state']
        if status.get('saturated'):
            self.saturated += 1
        if state == 'tracking' and self.previous_state == 'lost':
            self.recoveries += 1
        if state == 'stopped' and self.previous_state != 'stopped':
            self.terminal_stops += 1
        self.previous_state = state

    def check_done(self):
        if self.done or self.started is None:
            return
        duration = self.get_parameter('duration').value
        if self.completion_x < 8.0 and self.elapsed() < duration:
            return
        self.done = True
        rms = math.sqrt(self.sum_squared / max(1, self.samples))
        metrics = {
            'completion_x': self.completion_x, 'rms_error': rms,
            'peak_error': self.peak_error,
            'saturation_fraction': self.saturated / max(1, self.commands),
            'recoveries': self.recoveries, 'terminal_stops': self.terminal_stops,
            'max_gap': self.max_gap, 'samples': self.samples}
        passed = trial_passes(metrics)
        with open(self.get_parameter('output').value, 'w', newline='', encoding='utf-8') as handle:
            fields = ['duration_s', *metrics.keys(), 'passed']
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerow({'duration_s': self.elapsed(), **metrics, 'passed': passed})
        self.get_logger().info(f'trial complete passed={passed}')
        rclpy.shutdown()


def main():
    rclpy.init()
    rclpy.spin(TrialAnalyzer())
