import math


def track_y(x):
    return 0.42 * math.sin(0.72 * x) + 0.10 * math.sin(1.8 * x)


def cross_track_error(x, y):
    return y - track_y(x)
