import math

import rclpy
from geometry_msgs.msg import Point, TransformStamped, TwistStamped
from line_scout_interfaces.msg import LineSensorArray
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from visualization_msgs.msg import Marker

from .model import track_y


OFFSETS = [-0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15]


class TrackSimulator(Node):
    def __init__(self):
        super().__init__('track_simulator')
        self.declare_parameter('command_timeout', 0.25)
        self.x = self.y = self.yaw = 0.0
        self.linear = self.angular = 0.0
        self.last_command = None
        self.last_tick = self.get_clock().now()
        self.sensors = self.create_publisher(LineSensorArray, '/line_sensors', 20)
        self.odom = self.create_publisher(Odometry, '/odom', 20)
        self.path_pub = self.create_publisher(Path, '/line_scout/path', 10)
        self.track_pub = self.create_publisher(Marker, '/line_scout/track', 1)
        self.tf = TransformBroadcaster(self)
        self.path = Path()
        self.create_subscription(TwistStamped, '/cmd_vel', self.on_command, 20)
        self.create_timer(0.05, self.tick)

    def on_command(self, message):
        self.linear = float(message.twist.linear.x)
        self.angular = float(message.twist.angular.z)
        self.last_command = self.get_clock().now()

    def quaternion(self):
        return math.sin(self.yaw / 2.0), math.cos(self.yaw / 2.0)

    def tick(self):
        now = self.get_clock().now()
        dt = min(0.1, max(0.0, (now - self.last_tick).nanoseconds / 1e9))
        self.last_tick = now
        if (self.last_command is None or
                (now - self.last_command).nanoseconds / 1e9 > self.get_parameter('command_timeout').value):
            self.linear = self.angular = 0.0
        self.x += self.linear * math.cos(self.yaw) * dt
        self.y += self.linear * math.sin(self.yaw) * dt
        self.yaw += self.angular * dt
        self.publish_state(now)

    def publish_state(self, now):
        stamp = now.to_msg()
        qz, qw = self.quaternion()
        transform = TransformStamped()
        transform.header.stamp = stamp
        transform.header.frame_id = 'odom'
        transform.child_frame_id = 'base_link'
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.rotation.z = qz
        transform.transform.rotation.w = qw
        self.tf.sendTransform(transform)

        odom = Odometry()
        odom.header = transform.header
        odom.child_frame_id = 'base_link'
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw
        odom.twist.twist.linear.x = self.linear
        odom.twist.twist.angular.z = self.angular
        self.odom.publish(odom)

        readings = []
        for offset in OFFSETS:
            sx = self.x + 0.18 * math.cos(self.yaw) - offset * math.sin(self.yaw)
            sy = self.y + 0.18 * math.sin(self.yaw) + offset * math.cos(self.yaw)
            distance = sy - track_y(sx)
            reading = math.exp(-(distance * distance) / (2.0 * 0.035 * 0.035))
            if 3.5 <= sx <= 3.9:
                reading = 0.0
            readings.append(reading)
        sensor = LineSensorArray()
        sensor.header.stamp = stamp
        sensor.header.frame_id = 'line_sensor_array'
        sensor.reflectance = readings
        sensor.offsets = OFFSETS
        self.sensors.publish(sensor)

        pose = PoseStamped()
        pose.header = odom.header
        pose.pose = odom.pose.pose
        self.path.header = odom.header
        if len(self.path.poses) < 3000:
            self.path.poses.append(pose)
        self.path_pub.publish(self.path)
        self.publish_track(stamp)

    def publish_track(self, stamp):
        marker = Marker()
        marker.header.stamp = stamp
        marker.header.frame_id = 'odom'
        marker.ns = 'track'
        marker.id = 0
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.scale.x = 0.035
        marker.color.g = 0.9
        marker.color.a = 1.0
        marker.points = [Point(x=i * 0.04, y=track_y(i * 0.04)) for i in range(251)]
        self.track_pub.publish(marker)


def main():
    rclpy.init()
    node = TrackSimulator()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
