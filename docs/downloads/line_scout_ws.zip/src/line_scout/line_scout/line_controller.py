import json

import rclpy
from geometry_msgs.msg import TwistStamped
from line_scout_interfaces.msg import LineSensorArray
from rclpy.node import Node
from std_msgs.msg import String


class LineController(Node):
    def __init__(self):
        super().__init__('line_controller')
        defaults = {
            'enabled': True, 'kp': 7.0, 'kd': 0.8, 'max_speed': 0.32,
            'max_angular': 1.6, 'slowdown': 3.0, 'loss_threshold': 0.08,
            'recovery_speed': 0.16, 'recovery_turn': 0.7,
            'recovery_timeout': 3.0, 'sensor_timeout': 0.20,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        self.command = self.create_publisher(TwistStamped, '/cmd_vel', 20)
        self.status = self.create_publisher(String, '/line_scout/status', 20)
        self.last_sensor = self.last_error = self.last_error_time = None
        self.lost_since = None
        self.recoveries = 0
        self.was_lost = False
        self.create_subscription(LineSensorArray, '/line_sensors', self.on_sensor, 20)
        self.create_timer(0.05, self.watchdog)

    def publish(self, linear, angular, state, error=None, saturated=False):
        message = TwistStamped()
        message.header.stamp = self.get_clock().now().to_msg()
        message.header.frame_id = 'base_link'
        message.twist.linear.x = float(linear)
        message.twist.angular.z = float(angular)
        self.command.publish(message)
        self.status.publish(String(data=json.dumps({
            'state': state, 'error': error, 'saturated': saturated,
            'recoveries': self.recoveries})))

    def on_sensor(self, message):
        now = self.get_clock().now()
        self.last_sensor = now
        total = sum(message.reflectance)
        threshold = self.get_parameter('loss_threshold').value
        if total / len(message.reflectance) < threshold:
            if self.lost_since is None:
                self.lost_since = now
            self.was_lost = True
            elapsed = (now - self.lost_since).nanoseconds / 1e9
            if elapsed > self.get_parameter('recovery_timeout').value:
                self.publish(0.0, 0.0, 'stopped', self.last_error)
                return
            direction = 1.0 if (self.last_error or 0.0) >= 0.0 else -1.0
            self.publish(
                self.get_parameter('recovery_speed').value,
                direction * self.get_parameter('recovery_turn').value,
                'lost', self.last_error)
            return
        if self.was_lost:
            self.recoveries += 1
        self.was_lost = False
        self.lost_since = None
        error = sum(value * offset for value, offset in zip(message.reflectance, message.offsets)) / total
        dt = 0.0 if self.last_error_time is None else (now - self.last_error_time).nanoseconds / 1e9
        rate = 0.0 if not dt else (error - self.last_error) / dt
        self.last_error, self.last_error_time = error, now
        raw_angular = self.get_parameter('kp').value * error + self.get_parameter('kd').value * rate
        limit = self.get_parameter('max_angular').value
        angular = max(-limit, min(limit, raw_angular))
        speed_scale = max(0.25, min(1.0, 1.0 - self.get_parameter('slowdown').value * abs(error)))
        linear = self.get_parameter('max_speed').value * speed_scale
        if not self.get_parameter('enabled').value:
            linear = angular = 0.0
        self.publish(linear, angular, 'tracking' if self.get_parameter('enabled').value else 'observing',
                     error, abs(raw_angular) > limit)

    def watchdog(self):
        if self.last_sensor is None:
            return
        age = (self.get_clock().now() - self.last_sensor).nanoseconds / 1e9
        if age > self.get_parameter('sensor_timeout').value:
            self.publish(0.0, 0.0, 'stale')


def main():
    rclpy.init()
    node = LineController()
    try:
        rclpy.spin(node)
    finally:
        node.publish(0.0, 0.0, 'shutdown')
        node.destroy_node()
        rclpy.shutdown()
