# Line Scout workspace

Deterministic ROS 2 Jazzy line-following preview for Practical ROS 2.

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src --rosdistro jazzy -y
colcon build --symlink-install
source install/local_setup.bash
ros2 launch line_scout line_scout.launch.py
```

See the onsite course for estimation, tuning, recovery, and scoring. MIT licensed.
